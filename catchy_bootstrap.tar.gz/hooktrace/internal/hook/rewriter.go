package hook

// Package hook provides functionality to rewrite OCI hooks
// in a bundle's config.json to wrap them with a trace wrapper.

import (
    "fmt"
    "path/filepath"
    "time"

    "hooktrace/internal/spec"
)

// RewriteHooks rewrites the hooks in the given bundle so that each
// hook path is replaced by the path to our wrapper binary.  It
// returns a structure describing the original hooks for later
// restoration.  This is a stub implementation; actual writing to
// disk is not yet implemented.
func RewriteHooks(bundlePath string, wrapperPath string) (*spec.Bundle, error) {
    // TODO: read config.json, rewrite hook paths to wrapperPath, save the
    // original definitions for restoration.  For now we just load the bundle.
    cfgPath := filepath.Join(bundlePath, "config.json")
    b, err := spec.LoadBundle(cfgPath)
    if err != nil {
        return nil, err
    }
    // Just print a placeholder message for now.
    _ = wrapperPath
    return b, nil
}

// GenerateWrapper generates a trace wrapper binary and returns its
// path.  In the initial implementation this might simply be a
// symbolic link to a precompiled wrapper.  Here we return a
// placeholder path.
func GenerateWrapper(outputDir string) (string, error) {
    // TODO: build or extract the wrapper binary into outputDir.
    return filepath.Join(outputDir, fmt.Sprintf("wrapper-%d", time.Now().Unix())), nil
}