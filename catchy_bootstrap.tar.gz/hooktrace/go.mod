module hooktrace

go 1.20