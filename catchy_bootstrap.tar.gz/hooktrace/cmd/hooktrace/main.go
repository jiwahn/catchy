package main

import (
    "flag"
    "fmt"
    "os"
)

// version of hooktrace (update when releasing)
const version = "0.0.1"

// printUsage prints a basic usage message.
func printUsage() {
    fmt.Fprintf(os.Stderr, `Usage: hooktrace <command> [options]

Commands:
    inspect   Inspect an OCI bundle and list its hooks
    wrap      Rewrite hooks in a bundle to wrap them with a trace wrapper
    run       Wrap hooks and run the container via an OCI runtime
    report    Summarise collected hook trace logs

Use "hooktrace <command> -h" for more information about a command.
`)
}

func main() {
    if len(os.Args) < 2 {
        printUsage()
        os.Exit(1)
    }
    cmd := os.Args[1]
    switch cmd {
    case "inspect":
        inspectCmd(os.Args[2:])
    case "wrap":
        wrapCmd(os.Args[2:])
    case "run":
        runCmd(os.Args[2:])
    case "report":
        reportCmd(os.Args[2:])
    case "version":
        fmt.Println(version)
    case "help", "-h", "--help":
        printUsage()
    default:
        fmt.Fprintf(os.Stderr, "unknown command: %s\n", cmd)
        printUsage()
        os.Exit(1)
    }
}

// inspectCmd parses flags and calls the inspect subcommand.
func inspectCmd(args []string) {
    fs := flag.NewFlagSet("inspect", flag.ExitOnError)
    fs.Usage = func() {
        fmt.Fprintf(os.Stderr, "Usage: hooktrace inspect <bundle>\n\n")
        fs.PrintDefaults()
    }
    if err := fs.Parse(args); err != nil {
        os.Exit(1)
    }
    if fs.NArg() != 1 {
        fs.Usage()
        os.Exit(1)
    }
    bundle := fs.Arg(0)
    // TODO: call internal/spec to load and report hooks
    fmt.Printf("inspect called on bundle %s\n", bundle)
}

// wrapCmd rewrites hooks in the bundle.
func wrapCmd(args []string) {
    fs := flag.NewFlagSet("wrap", flag.ExitOnError)
    fs.Usage = func() {
        fmt.Fprintf(os.Stderr, "Usage: hooktrace wrap <bundle>\n\n")
        fs.PrintDefaults()
    }
    if err := fs.Parse(args); err != nil {
        os.Exit(1)
    }
    if fs.NArg() != 1 {
        fs.Usage()
        os.Exit(1)
    }
    bundle := fs.Arg(0)
    // TODO: call internal/hook to rewrite hooks
    fmt.Printf("wrap called on bundle %s\n", bundle)
}

// runCmd wraps hooks and runs the runtime.
func runCmd(args []string) {
    fs := flag.NewFlagSet("run", flag.ExitOnError)
    runtime := fs.String("runtime", "runc", "OCI runtime to use (runc, crun, etc.)")
    fs.Usage = func() {
        fmt.Fprintf(os.Stderr, "Usage: hooktrace run [--runtime runc] <bundle>\n\n")
        fs.PrintDefaults()
    }
    if err := fs.Parse(args); err != nil {
        os.Exit(1)
    }
    if fs.NArg() != 1 {
        fs.Usage()
        os.Exit(1)
    }
    bundle := fs.Arg(0)
    // TODO: call internal/hook.wrap + exec runtime
    fmt.Printf("run called on bundle %s with runtime %s\n", bundle, *runtime)
}

// reportCmd summarises collected hook logs.
func reportCmd(args []string) {
    fs := flag.NewFlagSet("report", flag.ExitOnError)
    format := fs.String("format", "text", "output format: text, json, yaml")
    fs.Usage = func() {
        fmt.Fprintf(os.Stderr, "Usage: hooktrace report [--format text] <trace-dir>\n\n")
        fs.PrintDefaults()
    }
    if err := fs.Parse(args); err != nil {
        os.Exit(1)
    }
    if fs.NArg() != 1 {
        fs.Usage()
        os.Exit(1)
    }
    traceDir := fs.Arg(0)
    // TODO: call internal/report to summarise logs
    fmt.Printf("report called on dir %s with format %s\n", traceDir, *format)
}